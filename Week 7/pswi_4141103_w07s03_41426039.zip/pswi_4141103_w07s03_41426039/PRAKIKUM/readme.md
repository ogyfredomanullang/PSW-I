1. Ringkasan Langkah Pengerjaan
Inisialisasi Repository & Initial Commit
Menyiapkan direktori proyek pada folder sesi 3 dan mengaktifkannya sebagai repository Git lokal menggunakan perintah git init.
Melakukan commit pertama untuk mengamankan struktur dasar file proyek ke dalam branch utama (master).
Pembuatan Branch Fitur
Membuat dan langsung berpindah ke branch baru bernama fitur-petunjuk dengan perintah git switch -c fitur-petunjuk.
Melakukan pembaruan teks penjelas format pengisian pada elemen formulir di dalam file daftar.html.
Menyimpan perubahan tersebut ke dalam branch fitur menggunakan pesan commit "Memperjelas petunjuk formulir".
Simulasi Code Review (review.md)
Menyusun file review.md guna mendokumentasikan tujuan perubahan kode, panduan pengujian melalui Live Server, serta catatan penting dari proses peninjauan.
Memasukkan dokumentasi tersebut ke dalam commit di branch fitur.
Penggabungan Perubahan (Merge)
Kembali ke branch utama (master) menggunakan perintah git switch master.
Menggabungkan seluruh pembaruan dari branch fitur-petunjuk ke branch utama memakai perintah git merge fitur-petunjuk.
Melakukan pengecekan ulang riwayat commit via git log --oneline -n 5 untuk memastikan alurnya bersih.

2. Riwayat Commit (Git Log)
50e0bb (HEAD -> master) Mengisi dokumentasi pada review.md
6641b3 (fitur-petunjuk) Memperjelas petunjuk formulir
12f16d Initial commit: struktur awal proyek minggu 7 sesi 3

3. Kesimpulan
Secara keseluruhan, rangkaian praktikum manajemen versi menggunakan Git—mulai dari pembuatan cabang, penambahan fitur, simulasi peninjauan, hingga proses merge—berhasil diselesaikan dengan rapi tanpa kendala berarti.

4. Matriks Uji dan Latihan Mandiri
Pada sesi latihan mandiri ini, alur kerja Git diterapkan secara disiplin di mana proses penambahan fitur dipisahkan ke dalam branch tersendiri (fitur-petunjuk). Proses review dilakukan secara terstruktur melalui catatan khusus, sehingga saat digabungkan ke branch utama (master), seluruh berkas tetap sinkron dan aplikasi web dapat berjalan normal.

Pengujian fungsional dibagi menjadi tiga skenario utama:

Kasus Normal: Formulir diisi menggunakan data valid sesuai ketentuan agar sistem dapat memprosesnya dengan lancar.
Kasus Batas: Pengujian dijalankan dengan membiarkan kolom wajib kosong untuk memicu peringatan validasi bawaan dari peramban.
Kasus Gagal: Menguji sistem dengan memasukkan format data yang keliru (misalnya alamat surel tanpa simbol @), sehingga sistem secara otomatis menolak pengiriman data dan memunculkan pesan galat.

5. Catatan Konflik CSS untuk Walkthrough UTS
Simulasi konflik pada CSS dikerjakan dengan menerapkan dua aturan berbeda untuk elemen header di dalam file style.css. Aturan pertama menetapkan latar belakang berwarna biru, lalu ditimpa oleh aturan kedua di bawahnya dengan warna merah. Berdasarkan prinsip cascade, aturan kedua berhasil menimpa aturan pertama, sehingga elemen header sukses berubah warna menjadi merah saat dilihat di peramban.

6. Catatan Troubleshooting
Kendala Tampilan: Apabila perubahan kode tidak langsung terlihat pada peramban, langkah perbaikannya adalah memastikan dokumen telah disimpan (Ctrl + S) serta memuat ulang halaman (refresh) pada peladen lokal.

Struktur Berkas & Path: Guna menghindari galat 404, penulisan direktori serta besar-kecilnya huruf pada nama folder dan berkas diperiksa kembali. Masalah tata letak atau ketidaksesuaian gaya diatasi dengan meneliti urutan spesifisitas pemilih (selector) melalui panel DevTools (tab Computed).

Kendala JavaScript: Penanganan galat pada skrip (seperti SyntaxError atau elemen bernilai null) dilakukan dengan membaca log pada konsol, memeriksa kelengkapan tanda kurung, serta memastikan waktu eksekusi skrip sudah tepat.

7. Pernyataan Penggunaan AI (AI Use Statement)
Bantuan asisten kecerdasan buatan dalam kegiatan ini dimanfaatkan sebatas sebagai teman berdiskusi untuk memperdalam pemahaman konsep dasar spesifisitas CSS, alur kerja Git, serta membantu merapikan struktur narasi laporan ini. Seluruh kode, saran, dan hasil uji coba telah divalidasi secara mandiri melalui eksperimen langsung menggunakan Live Server, pengujian formulir, dan terminal. Tidak ada data rahasia maupun informasi pribadi yang disertakan selama proses konsultasi, dan seluruh materi dapat dipertanggungjawabkan secara mandiri untuk persiapan walkthrough UTS.