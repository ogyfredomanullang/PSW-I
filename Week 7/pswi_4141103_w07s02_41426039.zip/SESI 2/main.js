const greetingButton = document.querySelector('#greeting-button');

if (greetingButton) {
    greetingButton.addEventListener('click', () => {
        alert('selamat belajar, pish out!');
        console.log('main.js berhasil dijalankan');
    });
}