1. Menyiapkan Halaman (Multipage Setup)

A. Susunan Berkas

Situs ini terdiri dari tiga halaman HTML yang memakai satu stylesheet CSS bersama:

index.html (Beranda)
kegiatan.html (Kegiatan)
daftar.html (Daftar)
css/style.css (Stylesheet bersama)

B. Pengaturan Dasar HTML

Ketiga file HTML sudah mengikuti ketentuan dasar berikut:

Title berbeda di tiap halaman: Setiap halaman punya <title> sendiri agar mudah dikenali di tab browser, misalnya “Beranda - IT Del”, “Daftar Kegiatan - IT Del”, dan “Form Pendaftaran - IT Del”.
Bahasa dan viewport: Saya memakai <html lang="id"> agar bahasa Indonesia terbaca dengan benar oleh teknologi pendukung aksesibilitas. Saya juga menambahkan <meta name="viewport" content="width=device-width, initial-scale=1.0"> supaya tampilan menyesuaikan lebar layar.
Stylesheet bersama: Semua halaman memanggil CSS yang sama lewat <link rel="stylesheet" href="css/style.css">.

C. Catatan Pengamatan dan Hasil Uji

Yang saya kerjakan:
Saya membuat tiga file HTML baru di folder proyek, yaitu index.html untuk beranda, kegiatan.html untuk kegiatan, dan daftar.html untuk pendaftaran. Setiap file saya beri judul <title> yang berbeda agar mudah dibedakan di tab browser. Di bagian <head>, saya menambahkan atribut bahasa Indonesia (lang="id") dan meta viewport agar halaman tampil pas di HP maupun laptop. Terakhir, ketiga halaman saya hubungkan ke satu file css/style.css supaya tampilannya seragam.

Hasil nyata (actual result):
Ketika dibuka dengan Live Server, ketiga halaman terbuka dengan lancar tanpa kendala.

2. Navigasi Konsisten

A. Tindakan

Saya menyalin pola navigasi yang sama ke semua halaman (index.html, kegiatan.html, daftar.html) dengan elemen <nav aria-label="Navigasi utama">.
Saya menambahkan aria-current="page" hanya pada tautan halaman yang sedang dibuka.
Pengujian yang saya lakukan:
Mengklik setiap tautan tujuan dari masing-masing halaman.
Memeriksa penanda halaman aktif lewat DevTools.
Mencoba tombol Back dan Forward pada browser.

B. Hasil Nyata

Semua tautan navigasi berfungsi dan tidak ada yang rusak (404). Penanda aria-current berpindah sesuai halaman yang sedang dibuka, dan tombol Back serta Forward browser juga bekerja normal.

3. Path dan Asset

A. Penjelasan Path

Semua aset dan file pendukung dipanggil dengan relative path yang konsisten di ketiga halaman:

Stylesheet bersama: css/style.css
Gambar/aset: assets/dog.jpg (atau nama gambar yang dipakai)

B. Aturan dan Konfigurasi Aset

Pemanggilan file dan aset mengikuti aturan dari modul:

Relative path: Tidak ada file yang dipanggil memakai alamat drive Windows seperti C:\Users\....
Huruf besar dan kecil (case sensitivity): Nama folder dan file di kode HTML ditulis persis sama dengan nama aslinya agar tidak error di server web.
Bebas 404: Semua aset dicek lewat tab Network di DevTools untuk memastikan statusnya sukses (200 OK).

C. Catatan Pengamatan dan Hasil Uji

Yang saya kerjakan:

Menghubungkan CSS dan gambar dengan relative path (css/style.css dan assets/...).
Mencocokkan huruf besar-kecil pada nama file di kode HTML dengan nama file di folder proyek.
Membuka tab Network di Developer Tools, lalu me-refresh halaman untuk melihat status respons tiap file.

Hasil nyata (actual result):

Semua gambar dan stylesheet termuat dengan baik, tanpa status error 404 Not Found.
Gambar tampil rapi di browser tanpa ada broken image.
Relative path tetap berjalan normal saat proyek dipindahkan atau dibuka lewat Live Server.
6. Audit Keseluruhan

A. Penjelasan Audit dan Integrasi

Pada tahap ini saya mengaudit ketiga halaman (index.html, kegiatan.html, dan daftar.html). Audit mencakup responsivitas tampilan, aksesibilitas keyboard, kevalidan HTML, dan kelancaran tautan antarhalaman. Semua ini diperiksa sebelum commit integrasi terakhir.

B. Aturan dan Langkah Audit

Aksesibilitas keyboard: Semua elemen navigasi dan formulir harus bisa difokuskan dan dioperasikan dengan tombol Tab dan Enter.
Responsivitas dan zoom: Tampilan diuji pada lebar 320px (HP) dan 1200px (desktop), serta saat di-zoom hingga 200%.
Validasi HTML: Memastikan tidak ada kesalahan sintaks pada file HTML.
Pemeriksaan tautan: Memastikan semua tautan navigasi dan tombol berfungsi tanpa galat 404.

C. Catatan Pengamatan dan Hasil Uji

Yang saya kerjakan:
Berpindah antar elemen dengan tombol Tab untuk memeriksa focus ring pada elemen interaktif.
Membuka Developer Tools (F12) untuk menguji tampilan di 320px dan 1200px, lalu mencoba zoom.
Memeriksa semua tautan navigasi di setiap halaman untuk memastikan tidak ada broken link.
Melakukan commit integrasi ke Git setelah semua pengujian berhasil.
Hasil nyata (actual result):
Semua tombol dan menu navigasi bisa dioperasikan penuh lewat keyboard.
Tampilan tetap fleksibel dan rapi di 320px, 1200px, dan saat di-zoom, tanpa elemen yang bertumpuk.
Semua tautan tersambung dengan benar, tanpa broken link atau error 404 Not Found.
Seluruh halaman terintegrasi secara konsisten.

D. Rincian Hasil Uji per Kasus

Uji keyboard (Tab dan Enter), semua halaman
Harapan: navigasi dan tombol bisa difokuskan serta dibuka lewat keyboard.
Hasil nyata: focus ring berpindah lancar dan semua tautan bisa diakses.
Status: Berhasil (lihat bukti/).
Uji layar 320px, 1200px, dan zoom, index.html
Harapan: beranda tampil konsisten dan responsif di berbagai ukuran.
Hasil nyata: layout menyesuaikan lebar layar tanpa horizontal scroll berlebih.
Status: Berhasil (lihat bukti/).
Uji layar 320px, 1200px, dan zoom, kegiatan.html
Harapan: teks dan gambar kegiatan tampil proporsional.
Hasil nyata: gambar dan teks tetap rapi di HP maupun desktop.
Status: Berhasil (lihat bukti/).
Uji layar 320px, 1200px, dan zoom, daftar.html
Harapan: formulir tetap rapi dan tidak tumpang tindih.
Hasil nyata: input, radio button, dan tombol submit mudah digunakan.
Status: Berhasil (lihat bukti/).
Validasi HTML, semua halaman
Harapan: kode HTML bebas kesalahan sintaks.
Hasil nyata: struktur HTML sesuai standar W3C tanpa pesan error.
Status: Berhasil (lihat bukti/).
Pemeriksaan tautan, semua halaman
Harapan: semua tautan navigasi berfungsi.
Hasil nyata: semua tautan tersambung lancar antarhalaman.
Status: Berhasil (lihat bukti/).
8. Troubleshooting dan AI Use Statement

A. Troubleshooting

Halaman tidak berubah
Simpan file dengan Ctrl + S, pastikan Live Server sedang berjalan, lalu refresh di URL server yang benar.
404 Not Found
Cek lagi susunan path, lokasi folder, dan penulisan huruf besar-kecil pada nama file.
CSS tidak sesuai atau tidak tampil
Pastikan file CSS sudah terpasang di HTML, periksa kemungkinan salah selector dan urutan cascade, lalu lihat tab Computed di DevTools.
ReferenceError / SyntaxError
Baca baris error di Console browser, cek scope variabel, dan pastikan semua pasangan tanda kurung lengkap.
Elemen null
Periksa lagi penulisan selector JavaScript dan pastikan script dipanggil setelah DOM selesai dimuat.
Data tidak sesuai
Telusuri alur parsing data, pengelolaan state, dan hasil render pada elemen HTML tujuan.

B. AI Use Statement

Alat AI yang digunakan: Gemini (Google AI).
Tujuan penggunaan:
Meminta penjelasan konsep pemrograman web, penggunaan Git, dan bantuan mendiagnosis error saat troubleshooting.
Menyusun draf struktur laporan README.md dan ringkasan langkah audit.
Bagian yang dibantu AI:
Konsultasi untuk mengatasi Git merge conflict dan konfigurasi repository.
Menyusun format draf dokumentasi atau laporan praktikum.
Verifikasi hasil:
Semua kode HTML, CSS, dan JavaScript saya uji langsung di browser dan DevTools.
Solusi Git saya jalankan sendiri lewat Terminal/CMD untuk memastikan hasilnya benar.
Tidak ada data rahasia seperti password, API key, atau data sensitif mahasiswa yang saya masukkan ke AI.