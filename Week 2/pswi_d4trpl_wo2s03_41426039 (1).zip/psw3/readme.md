lisensi gambar: https://share.google/DG1A6rHNxBNSNR9Lm
