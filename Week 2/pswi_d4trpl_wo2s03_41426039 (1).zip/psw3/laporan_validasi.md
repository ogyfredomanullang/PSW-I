VALIDASI BERTAHAP

Setelah dilakukan proses pemeriksaan secara bertahap, tidak ditemukan adanya kesalahan pada halaman yang diuji.

LATIHAN DEBUGGING

1. Salah satu tautan menggunakan nama file yang tidak sesuai

Saya sengaja mengubah nama file pada salah satu tautan untuk melihat hasil error. Ketika tombol **Kegiatan** diklik, halaman tidak dapat ditampilkan dan muncul pesan: Cannot GET /pswi-minggu-02%20-%20Copy/SESI_02/kegiatan.html-salah

Hal tersebut terjadi karena alamat atau nama file yang dituju pada tautan tidak sesuai dengan nama file yang sebenarnya.

2. Gambar tidak memiliki atribut alt

Apabila sebuah gambar tidak mempunyai atribut alt, pengguna tidak mendapatkan informasi pengganti ketika gambar gagal dimuat. Atribut alt dapat memberikan keterangan mengenai isi gambar sehingga informasi tetap dapat diketahui meskipun gambar tidak tampil.

3. Tabel tidak mempunyai caption

Setelah dilakukan pengujian, tabel masih dapat ditampilkan seperti biasa. Namun, karena tidak terdapat caption, tabel tersebut tidak mempunyai judul atau keterangan yang menjelaskan isi data di dalamnya.

4. Dua halaman menggunakan title yang sama

Ketika dua halaman diberikan judul yang identik, keduanya tetap dapat dibuka dan berfungsi. Akan tetapi, pengguna akan lebih sulit membedakan halaman tersebut karena nama yang ditampilkan pada tab browser sama.

REFLEKSI

1. Apa perbedaan tautan relatif dan tautan absolut?
Tautan relatif menentukan lokasi tujuan berdasarkan posisi file yang sedang digunakan. Sementara itu, tautan absolut mencantumkan alamat lengkap menuju halaman atau sumber yang dituju.

2. Kapan alt harus menjelaskan gambar dan kapan alt boleh kosong?
Atribut alt sebaiknya berisi penjelasan apabila gambar menyampaikan informasi yang penting bagi pengguna. Sebaliknya, alt dapat dikosongkan apabila gambar hanya berfungsi sebagai elemen dekoratif dan tidak memberikan informasi tambahan.

3. Mengapa tabel tidak digunakan untuk layout?
Tabel dibuat untuk menyajikan serta menghubungkan data dalam bentuk baris dan kolom. Pengaturan tata letak halaman sebaiknya menggunakan struktur HTML dan CSS, bukan menggunakan tabel.

4. Bukti apa yang menunjukkan bahwa halaman telah diuji, bukan hanya dilihat?
Salah satu bukti bahwa halaman benar-benar telah melalui proses pengujian adalah adanya screenshot hasil pengujian. Screenshot tersebut dapat menunjukkan kondisi halaman setelah dilakukan berbagai percobaan, termasuk ketika terjadi error maupun setelah kesalahan diperbaiki.