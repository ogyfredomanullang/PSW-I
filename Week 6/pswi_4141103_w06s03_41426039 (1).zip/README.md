Nama : Ogi Fredo Manullang 
NIM : 41426039
Prodi : D4 TRPL

1. GAMBAR FLEKSIBEL

Tindakan yang saya lakukan: Saya masukin foto sendiri ke folder assets, terus nambahin kode CSS ini: CSS img { max-width: 100%; height: auto; } Saya juga isi width dan height di tag img sesuai ukuran aslinya (640x360). Hasil nyata yang tampil di layar: Pas saya cek di tab Network, gambarnya gak 404. Pas jendela browser saya kecilin, gambarnya ikut menyusut dan rasionya tetap, gak gepeng.

2. KANDIDAT RESOLUSI

Tindakan yang saya lakukan: Saya bikin 2 versi gambar pake editor gambar, foto-320.jpg dan foto-640.jpg. Terus tag img saya ubah pake srcset dan sizes: HTML <img src="assets/foto-640.jpg" srcset="assets/foto-320.jpg 320w, assets/foto-640.jpg 640w" sizes="(min-width: 48rem) 50vw, 92vw" width="640" height="360" alt="Kegiatan diskusi mahasiswa"> Habis itu saya cek currentSrc di Console, dan saya coba juga dengan cache dimatikan di tab Network. Hasil nyata yang tampil di layar: Di lebar 320px yang kepilih foto-320.jpg, di 1200px yang kepilih foto-640.jpg. Pas jendela saya geser-geser setelah halaman kebuka, browser kadang tetap pake file yang gede, jadi harus di-refresh dulu baru kelihatan perubahannya.

3. FLUID FONT DAN CONTAINER QUERY

Tindakan yang saya lakukan: Saya nambahin kode CSS ini: CSS h1 { font-size: clamp(1.75rem, 1.2rem + 2vw, 3rem); } .card-wrap { container-type: inline-size; } @container (min-width: 30rem) { .card { padding: 1.5rem; } } Terus saya catat font Computed di 2 ukuran layar, dan saya ubah lebar .card-wrap tanpa ngubah ukuran viewport. Hasil nyata yang tampil di layar: Font h1 di 320px = 28px, di 1200px sekitar 43,2px. Padding card baru berubah jadi 1,5rem pas lebar pembungkusnya nyampai 30rem, padahal ukuran layar gak diubah. Jadi @media ngikutin lebar layar, sedangkan @container ngikutin lebar pembungkusnya.

4. REDUCED MOTION DAN AUDIT

Tindakan yang saya lakukan: Saya nambahin kode CSS ini: CSS @media (prefers-reduced-motion: reduce) { .card { transition: none; } } Terus saya aktifin emulasi reduced motion di DevTools, lalu tes lagi pake tombol Tab dan zoom 200%. Hasil nyata yang tampil di layar: Pas reduced motion nyala, transisi card hilang tapi fungsi halamannya tetap jalan. Tombol Tab lancar, zoom 200% teksnya tetap kebaca, dan gak ada informasi yang cuma muncul pas di-hover.

5. LATIHAN MANDIRI DAN MATRIKS UJI

Prediksi Sebelum Eksperimen: Gambar path: Gambar diharapkan termuat tanpa 404. Container sempit/lebar: Query container aktif sesuai lebar pembungkus. Zoom 200%: Teks tetap terbaca dan gak terpotong. Reduced motion: Transisi berkurang atau hilang.

Hasil Nyata Pengamatan: Kasus normal: Saya buka di 320px, 768px, dan 1200px, tampilannya rapi dan gak ada scroll samping. Kasus batas: Saya isi judul card pake teks panjang tanpa spasi, hasilnya teks turun ke bawah dan gak keluar dari card. Kasus gagal: Saya sengaja salahin path gambar, hasilnya gambar gak muncul, di Network 404, dan yang tampil cuma alt text. Setelah path saya benerin, gambarnya muncul lagi.

