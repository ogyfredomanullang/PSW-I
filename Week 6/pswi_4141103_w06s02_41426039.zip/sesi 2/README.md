Nama : Ogi Fredo Manullang 
NIM : 41426039
Prodi : D4 TRPL

1. STARTER MOBILE

Tindakan yang saya lakukan: Saya membuka menu Developer Tools pada peramban, lalu menguji responsivitas halaman web pada lebar viewport 320px.
Hasil nyata yang tampil di layar: Tataletak layar secara otomatis menyesuaikan dengan ukuran media, dan elemen teks mengalir serta memanjang ke bawah mengikuti lebar layar.

2. BREAKPOINT KONTEN
Tindakan yang saya lakukan:
Saya menambahkan kode ke CSS saya:
CSS
@media (min-width: 48rem) {
  .catalog { grid-template-columns: repeat(2, 1fr); }
}

Hasil nyata yang tampil di layar:

Saya tes di browser pake ukuran 767px, 768px, dan 769px buat liat di ukuran berapa layoutnya berubah dari 1 kolom jadi 2 kolom. Pas dicoba, ternyata di ukuran 768px dan 769px sudah nyampai batas minimum 48rem, jadi layout tampilannya langsung berubah jadi 2 kolom.

3. NAVIGASI DAN FORM
Tindakan yang saya lakukan:

Saya nambahin kode CSS ini:
CSS
.nav-list { display: flex; flex-wrap: wrap; gap: .75rem; }
input, select, textarea { max-width: 100%; }

Hasil nyata yang tampil di layar:
Setelah ngelakuin 3 pengujian sederhana (tes label panjang, cek kotak form biar gak meluber, sama tes tombol Tab):
Pas tes label panjang, teksnya gak kepotong atau keluar dari kotak.
Kotak form juga gak ada yang meluber keluar.
Pengujian aksesibilitas pake tombol Tab berjalan lancar buat pindah-pindah elemen.

4. MATRIKS VIEWPORT

Tindakan yang saya lakukan:

Saya nambahin .card { min-width: 0; } ke CSS biar elemen flex/grid di dalamnya gak tertahan di lebar minimum bawaannya.
Terus saya tes di 3 ukuran layar: 320px (mobile), 768px (tablet), dan 1200px (desktop).
Saya juga nyoba tes zoom browser sampai 200%.
Saya sengaja nambahin width: 900px buat simulasi masalah, terus habis itu saya benerin lagi.

Hasil Nyata Pengamatan:

Pas dites di ukuran 320px, 768px, dan 1200px, layarnya gak ada masalah dan tampilannya menyesuaikan dengan rapi.
Pas di-zoom 200%, teks sama elemen yang ada tetap bisa dibaca dengan jelas tanpa bikin tampilannya berantakan.
Simulasi Overflow (Before vs After):
Before: Pas ditambahin width: 900px, muncul scrollbar ke samping karena layarnya terlalu sempit.
After: Pas saya ganti jadi max-width: 100%, scrollbar sampingnya langsung hilang dan tata letaknya aman lagi.

5. LATIHAN MANDIRI DAN MATRIKS UJI

Prediksi Sebelum Eksperimen:

Kasus 320px: Konten diharapkan tetap lengkap dan tampil rapi 1 kolom tanpa ada scroll horizontal.
Sekitar Breakpoint: Media query aktif sesuai kondisi perubahan ukuran layar.
Zoom 200%: Konten tidak terpotong dan tetap bisa dibaca dengan jelas.
Keyboard: Fokus navigasi kelihatan jelas pas tombol Tab ditekan.




