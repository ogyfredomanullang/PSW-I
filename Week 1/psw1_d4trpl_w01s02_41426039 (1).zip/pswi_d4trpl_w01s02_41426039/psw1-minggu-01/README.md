Nama : Ogi Fredo Manullang 
NIM : 41426039
Prodi : Rekaysa Perangkat Lunak 
Laporan praktikum
Kegunaan dari elements : Menampilkan struktur kode HTML dan gaya CSS dari halaman web secara real-time. Bagian ini memungkinkan pengguna melihat tata letak, mengubah atribut atau gaya visual secara sementara, serta menganalisis elemen DOM
kegunaan dari console: Berfungsi sebagai papan catatan untuk melihat log, peringatan,dan error JavaScript saat skrip web berjalan.
kegunaan dari network : Mencatat seluruh proses pengiriman (request) dan penerimaan (response) data antara browser dan server.