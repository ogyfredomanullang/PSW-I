Nama : Ogi Fredo Manullang
NIM : 41426039
Prodi : D4 TRPLS



3. Mengubah Container
Di bagian ini, class cards yang ada di HTML diganti jadi catalog. Terus, Flexbox yang tadinya dipakai buat ngatur container ditukar pakai CSS Grid (display: grid sama grid-template-columns: 1fr 1fr). Hasilnya, card langsung otomatis tersusun jadi dua kolom.

4. Grid Adaptif
Nah, di sini nilai grid-template-columns-nya diubah lagi pakai repeat(auto-fit, minmax(min(100%, 15rem), 1fr)). Tujuannya biar jumlah kolomnya bisa nyesuaiin sendiri ukurannya ngikutin layar. Kemarin sempat diuji coba di tiga ukuran layar: 320 px, 768 px, sama 1200 px. Saya juga sengaja nambahin satu card lagi (jadi total lima) buat ngecek apakah card-nya bisa turun sendiri ke baris berikutnya kalau layar penuh.

5. Card Internal dan Gap
Untuk bagian dalamnya, tiap card diset pakai display: flex, flex-direction: column, dan gap: .5rem. Pengaturan ini bikin isi di dalam card jadi rapi tersusun ke bawah dengan jarak yang pas. Margin buat judul sama paragraf dibikin 0, terus untuk link-nya dikasih align-self: start supaya ukurannya nggak ikut melebar nutupin lebar card. Semuanya pakai class yang sama biar konsisten.

6. Review Layout
Di tahap ini, urutan kodingan HTML-nya dicek lagi biar pas sama tampilan visual sekaligus enak kalau diakses pakai keyboard. Properti overflow-wrap: anywhere juga dipasang supaya teks yang kepanjangan bisa otomatis turun ke bawah dan nggak keluar jalur dari card-nya. Pengujiannya dicoba pakai 1 card doang sampai 5 card sekaligus buat mastiin tampilannya tetap enak dibaca.

7. Hasil Pengujian
Ukuran 320 px: Nyoba ngecilkan lebar viewport ke 320 px.
Ukuran 768 px: Nyoba menyesuaikan lebar viewport ke 768 px.
Ukuran 1200 px: Nyoba memperlebar viewport ke 1200 px.