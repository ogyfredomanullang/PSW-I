Nama : Ogi Fredo Manullang
NIM : 41426039
Prodi : TRPL


TUJUAN
Praktikum ini bertujuan untuk memahami penggunaan display: flex pada CSS, supaya tata letak elemen di website bisa menyesuaikan ukurannya secara otomatis mengikuti layar perangkat yang dipakai.

PENJELASAN PERUBAHAN
Perubahan fokus pada penyesuaian layout agar tampilan web bisa langsung beradaptasi dan tetap rapi saat dibuka di berbagai ukuran layar pengguna.

HASIL UJI
Dari hasil pengujian, pas layar dikecilin, elemen "Lokakarya HTML", "Diskusi CSS", dan "Audit Web" otomatis berubah susunannya jadi memanjang ke bawah, ngikutin tampilan standar di HP.

BATASAN
Praktikum ini masih sebatas menggunakan halaman formulir sederhana, dan pengujiannya baru dilakukan secara lokal di browser.