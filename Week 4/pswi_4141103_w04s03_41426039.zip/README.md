Nama : Ogi Fredo Manullang
NIM : 41426039
Prodi : TRPL






Laporan Praktikum Pengembangan Situs Web I (4141103)Minggu 4 / Sesi 3: Unit, Tipografi, dan Sistem Gaya DasarInstitut Teknologi Del - D4 Teknologi Rekayasa Perangkat Lunak1. Identitas MahasiswaNama: [Nama Mahasiswa]NIM: [NIM Mahasiswa]Kelas: D4 TRPL 2026Tanggal Sesi: Minggu 4 Sesi 3Waktu Pengerjaan: 120 Menit2. Struktur Direktori Proyekpswi-week-04/
└── sesi-03/
    ├── index.html
    ├── style.css
    ├── README.md
    └── bukti/
        ├── screenshot-normal.png
        ├── screenshot-zoom-200.png
        ├── screenshot-custom-properties.png
        └── screenshot-focus-visible.png
3. Cara Menjalankan ProyekBuka VS Code dan arahkan direktori kerja ke pswi-week-04/sesi-03/.Pastikan ekstensi Live Server sudah aktif.Buka file index.html, klik kanan lalu pilih Open with Live Server.Aplikasi dapat diakses melalui browser pada port lokal (misalnya http://127.0.0.1:5500).Gunakan DevTools (F12) untuk memeriksa tata letak elemen pada tab Elements, Console, dan Computed.4. Penjelasan Implementasi & Perubahan KodeA. Reset Ukuran Kotak (Box Model Reset)Menerapkan aturan *, *::before, *::after { box-sizing: border-box; } untuk memastikan perhitungan padding dan border berada di dalam dimensi lebar total elemen.Wadah utama main dikonfigurasi menggunakan width: 100%, max-width: 60rem, dan margin-inline: auto agar posisi konten berada di tengah dan responsif secara horizontal.B. Token Warna dan Jarak (CSS Custom Properties)Variabel terpusat didefinisikan pada pseudo-class :root::root {
  --brand: #175cd3;
  --ink: #243244;
  --surface: #ffffff;
  --space: 1rem;
}
Seluruh komponen seperti .card, button, dan indikator fokus merujuk pada variabel tersebut, sehingga pengubahan warna atau jarak utama dapat dilakukan dari satu titik tanpa menggunakan !important.C. Tipografi dan Unit RelativePenggunaan unit relative rem pada basis dokumen (font-size: 1rem) serta line-height: 1.6 tanpa unit untuk menjaga keterbacaan proporsional.Paragraf informasi .notice diberi batasan max-width: 65ch untuk menjaga jumlah karakter per baris berada di kisaran ideal membaca.D. Aksesibilitas & Focus StatesMenggunakan :focus-visible pada elemen input dan tombol untuk memberikan indikator garis luar (outline) yang jelas ketika diakses melalui keyboard:input:focus-visible, button:focus-visible {
  outline: 3px solid var(--brand);
  outline-offset: 3px;
}
5. Matriks PengujianInput / KondisiTindakanHasil AktualStatus / BuktiKasus NormalResolusi layar standar (Desktop/Laptop).Membuka halaman index.html via server lokal.Formulir tampil dalam kartu terpusat, teks terbaca jelas, dan ukuran elemen proporsional.PASSbukti/screenshot-normal.pngKasus BatasZoom browser dinaikkan hingga 200%.Menekan tombol Ctrl + di browser sampai zoom 200%.Teks dan form melakukan penyesuaian (reflow), tidak ada teks yang terpotong atau keluar dari batas layar.PASSbukti/screenshot-zoom-200.pngKasus TokenMengubah nilai variabel --brand pada :root.Mengubah nilai --brand dari #175cd3 menjadi warna lain.Semua komponen yang merujuk pada --brand (tombol, outline fokus) berubah secara konsisten.PASSbukti/screenshot-custom-properties.pngKasus AksesibilitasNavigasi keyboard menggunakan tombol Tab.Menekan tombol Tab berulang kali dari bilah alamat.Ring fokus berwarna tebal dengan outline-offset: 3px muncul secara berurutan pada input dan tombol.PASSbukti/screenshot-focus-visible.pngKasus Teks PanjangMengisi elemen paragraf dengan teks > 100 kata.Memasukkan teks panjang ke dalam <p class="notice">.Teks terbungkus rapi dengan lebar maksimum 65 karakter per baris (65ch) tanpa mematahkan tata letak.PASSbukti/screenshot-longtext.png6. Laporan Troubleshooting & DiagnosisKonflik Perhitungan Lebar Input Form:Gejala: Input teks keluar dari area kartu .card saat diatur width: 100%.Penyebab: Perhitungan bawaan browser (content-box) menambah padding di luar lebar elemen.Solusi: Menambahkan deklarasi box-sizing: border-box pada reset global.Pengujian Penelusuran Specificity & Cascade:Pemeriksaan: Dipastikan aturan gaya :focus-visible diletakkan setelah deklarasi input dan button agar tidak tertimpa aturan dasar tanpa perlu menambahkan !important.7. Pernyataan Penggunaan AI (AI Use Statement)Alat AI: GeminiTujuan Penggunaan: Membantu penyusunan struktur Laporan README.md dan verifikasi kriteria pengujian sesuai standar WCAG/W3C.Bagian Bantuan: Penyusunan matriks pengujian, pembuatan contoh teks diagnosis box model, dan ringkasan langkah-langkah kerja.Verifikasi Mandiri: Seluruh kode HTML dan CSS telah diuji dan dikonfirmasi langsung menggunakan browser modern dan Live Server.8. Persiapan Pertemuan Berikutnya (Minggu 5)Menyiapkan elemen markup HTML berupa 3 card kegiatan beserta komponen navigasi utama untuk latihan modul Flexbox dan CSS Grid pada pertemuan selanjutnya.