Nama : Ogi Redo Manullang 
NIM : 41426039
Prodi : TRPL




1. ISI STRUKTUR
Sebuah direktori bernama `psw1-week-04` disiapkan sebagai wadah utama untuk mengintegrasikan berkas CSS eksternal, menerapkan pemilih selector secara presisi, serta menganalisis bentrokan gaya (cascade) memakai perangkat DevTools. Di dalamnya diisi dengan dokumen `index.html`, stylesheet `style.css`, skrip `main.js`, serta direktori `bukti` khusus untuk menampung seluruh dokumentasi tangkapan layar.
2. STYLESHEET
Pemasangan baris perintah `<link rel="stylesheet" href="style.css">` pada dokumen HTML berfungsi menghubungkan aturan gaya visual dari file CSS. Hasilnya, tampilan situs dapat dipoles dengan skema warna yang menarik serta tata letak elemen yang lebih terstruktur.
3. SELECTOR DAN CLASS
Melalui deklarasi CSS seperti `form.card { padding: 1rem; background: white; }` dan `.notice { color: #175cd3; }`, kita dapat mengontrol serta menyesuaikan estetika visual—seperti latar belakang dan skema warna—pada formulir yang menggunakan kelas terkait di dalam HTML.
4. KONFLIK  SPECIFICITY
Guna menentukan tampilan elemen tertentu secara presisi saat terjadi bentrokan aturan CSS, selector `.card p` dimanfaatkan untuk mengkustomisasi gaya teks paragraf di dalam komponen kartu. Di saat bersamaan, aturan `.notice` diterapkan guna memberikan sentuhan visual khusus bagi elemen yang memiliki kelas tersebut.
5. UKURAN KOTAK
Perhitungan awal lebar komponen formulir tanpa memperhitungkan margin menghasilkan nilai total 276px (dari kalkulasi 240 + 32 + 4 + 0). Karena ukuran tersebut melebihi batas ideal dan merusak kerapian tata letak, penerapan properti `box-sizing: border-box` pada kelas `.card` dalam berkas CSS menjadi solusi ampuh untuk mengunci dimensi totalnya agar tetap tepat di angka 240px.
